import React from "react"; 

function Haku() {
    return (
        <p>
            <input type= 'text' name='Haku' placeholder="Hae arvosteluja" />
            <input type='submit' value='Hae' />
        </p>
    );
}

export default Haku;