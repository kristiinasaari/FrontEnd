import React from "react"; 

function Kosmetiikka() {
    return (
        <p>
            Merkki: <br />
            Nimi: <br />
            Kategoria: <br />
            Luokitus: <br />
            Kuvaus: <br />
        </p>
    );
}

export default Kosmetiikka;