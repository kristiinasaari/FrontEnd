import React from "react";
import Tiedot from "./components/Tiedot"

function App() {
  return (
    <div>
        <Tiedot />
    </div>
  );
}

export default App;
